import React from 'react';
import ReactDom from 'react-dom';
import './avatarbackground.jpg'
import './indexCustom.css'

//第一部分组件
function Avatar(props){
	return (
		<div>
			<img  className={props.className} src={"https://www.gravatar.com/avatar/3edc01cbcb343fae0030d2dfcfb40166?s="+ props.size} />
		</div>
	);
}

function Introduction(props){
	return (
		<div className="row">
			<h1 className="col-xs-12">欢迎来到碧哥の站</h1>
			<hr className="col-xs-12"/>
			<p className="col-xs-12 col-md-offset-2 col-md-10 introductionPragraph">
				这是一个私人搭建的网站<br/>
				旨在分享我本人的一些学习笔记、感悟以及经验<br/>
				另有一些模块应用于存储一些私人文件或用于朋友间的交流<br/>
				这些部分需要额外的权限才能浏览
			</p>
		</div>
	)
}
function AppAvatar(props){
	return (
		<div className="headAvatar container" >
			<div className="row">
				<div className="col-xs-2">
					<Avatar className="avatar" size="100" />
				</div>
			</div>
			<div className="row introduction">
				<div className="col-xs-12">
					<Introduction />
				</div>
			</div>
		</div>
	);
}



//第二部分组件

function AppNavbar(props){
	return (
		<div className="container">
			<div className="row">
				<Navbar />
			</div>
		</div>
	)
}

function Navbar(props){
	return (		
			<nav className="navbar navbar-default">
				<div className="container">
					{/*为了实现行内的垂直和水平方向的布局，必须要新嵌套一个行，并为这个行采用flex布局*/}
					<div className="row navbarRow">
						<div className="navbar-header col-md-offset-1 col-md-1">
							{/*为了实现行内的垂直和水平方向的布局，必须要新嵌套一个行，并为这个行采用flex布局*/}
							<div className="row navbarRowmobile">
								<button type="button" class="col-xs-offset-3 col-xs-2 navbar-toggle" data-toggle="collapse" data-target="#collapseTarget">
								<span className="icon-bar"></span>
								<span className="icon-bar"></span>
								<span className="icon-bar"></span>
								</button>
								<div className="col-xs-2 navbarAvatar">
									<Avatar className="avatar" size="30"/>
								</div>
							</div>
						</div>

						<div className=" col-md-8 collapse navbar-collapse " id="collapseTarget">
							<ul className="nav nav-pills nav-justified navList">
								<li class="active"><a href="">首页</a></li>
								<li><a href="">学习笔记</a></li>
								<li><a href="">web开发推荐</a></li>
								<li><a href="">Private</a></li>
							</ul>
						</div>
					</div>
				</div>
			</nav>		
	)
}


/*第三部分组件*/


function App(props){
	return (
		<div>
			<AppAvatar />
			<AppNavbar />
		</div>
	);
}

ReactDom.render(
	<App />,
	document.getElementById("root")
)