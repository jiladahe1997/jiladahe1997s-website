import React from 'react';
import ReactDom from 'react-dom';
import './avatarbackground.jpg'
import './indexCustom.css'

//第一部分组件
function Avatar(props){
	return (
		<div>
			<img  className={props.className} src={"https://www.gravatar.com/avatar/3edc01cbcb343fae0030d2dfcfb40166?s="+ props.size} />
		</div>
	);
}

function Introduction(props){
	return (
		<div className="row">
			<h1 className="col-xs-12">欢迎来到碧哥の站</h1>
			<hr className="col-xs-12"/>
			<p className="col-xs-12 col-md-offset-2 col-md-10 introductionPragraph">
				这是一个私人搭建的网站<br/>
				旨在分享我本人的一些学习笔记、感悟以及经验<br/>
				另有一些模块应用于存储一些私人文件或用于朋友间的交流<br/>
				这些部分需要额外的权限才能浏览
			</p>
		</div>
	)
}
function AppAvatar(props){
	return (
		<div className="head container" >
			<div className="row avatarInhead">
				<div className="col-xs-12">
					<Avatar className="avatar" size="100" />
				</div>
			</div>
			<div className="row introductionInhead">
				<div className="col-xs-12">
					<Introduction />
				</div>
			</div>
		</div> 
	); 
}



//第二部分组件

function AppNavbar(props){
	return (
		<div className="container">
			<div className="row">
				<div className="col-xs-12">
					<Navbar />
				</div>
			</div>
		</div>
	)
}

function Navbar(props){
	return (		
			<nav className="navbar navbar-default">
				<div className="container-fluid">
									
						<div className="navbar-header">
							<div className="avatardivInnav">
								<Avatar className="avatarInnav" size="30"/>
							</div>
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#collapseTarget">
							<span className="icon-bar"></span>
							<span className="icon-bar"></span>
							<span className="icon-bar"></span>
							</button>								
						</div>

						<div className=" collapse navbar-collapse" id="collapseTarget">
							<ul className="nav nav-pills nav-justified navList">
								<li class="active"><a href="">首页</a></li>
								<li><a href="">学习笔记</a></li>
								<li><a href="">web开发推荐</a></li>
								<li><a href="">Private</a></li>
							</ul>
						</div>
					
				</div>
			</nav>		
	)
}


/*第三部分组件*/


function App(props){
	return (
		<div>
			<AppAvatar />
			<AppNavbar />
		</div>
	);
}

ReactDom.render(
	<App />,
	document.getElementById("root")
)